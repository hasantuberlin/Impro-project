Data Example or one patient in the Physionet data, two types of data, clinical record and wave record.

From the PhysioNet/mimic2cdb/CINC/MAP file:

Clin.	Wave.   Sex	Age	Birthdate	Waveform
Record  Record					Record Date

s05336	a40834	M	40	17/01/1971	31/05/2011

Wave Record:
Physionet/mimic2wdb/CINC/train-set/H1/a40834n.csv

Clinical Record:
PhysioNet/mimic2cdb/CINC/s0533/
   s05336.log
   s05336.txt
   s05336.hea
   index.html
